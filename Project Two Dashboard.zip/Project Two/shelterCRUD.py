from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username='aacuser', password='SNHUstudent1', 
                 host='nv-desktop-services.apporto.com', port=31294, db='AAC', col='animals'):
        # Initialize MongoDB connection
        self.client = MongoClient(f'mongodb://{username}:{password}@{host}:{port}/{db}?authSource=admin')
        self.collection = self.client[db][col]


    def create(self, data):
        if data:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"An error occurred: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, query=None):
        # Default to empty dictionary if no query is provided
        if query is None:
            query = {}
        try:
            results = list(self.collection.find(query))
            return results
        except Exception as e:
            print(f"An error occurred: {e}")
            return []

    def update(self, query, new_values):
        if query and new_values:
            try:
                result = self.collection.update_many(query, {"$set": new_values})
                return result.modified_count
            except Exception as e:
                print(f"An error occurred: {e}")
                return 0
        else:
            raise Exception("Query or new_values parameters cannot be empty")

    def delete(self, query):
        if query:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print(f"An error occurred: {e}")
                return 0
        else:
            raise Exception("Query parameter cannot be empty")

